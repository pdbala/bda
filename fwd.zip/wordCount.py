def count_words(file_path):
    word_counts = {}

    # Open the file
    with open(file_path, 'r') as file:
        # Read each line
        for line in file:
            # Split the line into words
            words = line.split()
            # Count occurrences of each word
            for word in words:
                # Remove punctuation marks from the word
                word = word.strip(".,?!;:\"'")
                # Convert the word to lowercase to ensure case-insensitivity
                word = word.lower()
                # Increment the count for the word
                word_counts[word] = word_counts.get(word, 0) + 1

    return word_counts

def main():
    file_path = "/home/ram/Desktop/New Folder/content.txt"
    word_counts = count_words(file_path)

    print("Word counts:")
    for word, count in word_counts.items():
        print(f"{word}: {count}")

if __name__ == "__main__":
    main()
